package com.example.SpringCrudMongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrudFunctionMdbAssignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudFunctionMdbAssignment2Application.class, args);
	}

}
