package com.example.SpringCrudMongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCrudFunctionMdbAssignment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
